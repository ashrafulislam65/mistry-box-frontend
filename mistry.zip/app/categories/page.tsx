"use client";

import { useEffect, useState, Suspense } from "react";
import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import { getPackages, getCategories } from "@/lib/api";
import PackageCard from "@/components/PackageCard";
import Pagination from "@/components/Pagination";
import { Package, Category } from "@/types";

const PAGE_SIZE = 12;

function CategoriesContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const categorySlug = searchParams.get("category") || "";
  const page = Number(searchParams.get("page")) || 1;

  const [packages, setPackages] = useState<Package[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getCategories().then((res) => setCategories(res.data || []));
  }, []);

  useEffect(() => {
    setLoading(true);
    getPackages({ category: categorySlug || undefined, page, limit: PAGE_SIZE })
      .then((res) => {
        setPackages(res.data || []);
        setTotalPages(res.pagination?.totalPages || 1);
      })
      .finally(() => setLoading(false));
  }, [categorySlug, page]);

  function goToPage(p: number) {
    const params = new URLSearchParams();
    if (categorySlug) params.set("category", categorySlug);
    params.set("page", String(p));
    router.push(`/categories?${params.toString()}`);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function selectCategory(slug: string) {
    const params = new URLSearchParams();
    if (slug) params.set("category", slug);
    router.push(`/categories?${params.toString()}`);
  }

  return (
    <main className="site-shell">
      <header className="site-header">
        <div className="container header-inner">
          <Link href="/" className="brand-name">
            <span className="brand-icon">📦</span>Darazz Mystery Box
          </Link>
          <nav className="nav-links">
            <Link href="/categories">ক্যাটাগরি</Link>
            <Link href="/contact">যোগাযোগ</Link>
          </nav>
        </div>
      </header>

      <section className="hero" style={{ padding: "60px 0 40px" }}>
        <div className="container">
          <h1 style={{ fontSize: "clamp(28px, 4vw, 40px)" }}>সব ক্যাটাগরি</h1>
          <p>আপনার প্রয়োজন অনুযায়ী মিস্ত্রি বক্স বেছে নিন।</p>
        </div>
      </section>

      <div className="container" style={{ marginBottom: 24 }}>
        <div className="toolbar" style={{ justifyContent: "center" }}>
          <button
            className={`btn ${!categorySlug ? "btn-accent" : "btn-outline"}`}
            onClick={() => selectCategory("")}
          >
            সব
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              className={`btn ${categorySlug === c.slug ? "btn-accent" : "btn-outline"}`}
              onClick={() => selectCategory(c.slug)}
            >
              {c.name}
            </button>
          ))}
        </div>
      </div>

      <div className="container" style={{ paddingBottom: 60 }}>
        {loading ? (
          <p style={{ textAlign: "center" }}>Loading...</p>
        ) : packages.length === 0 ? (
          <p style={{ textAlign: "center" }}>কোনো প্যাকেজ পাওয়া যায়নি।</p>
        ) : (
          <>
            <div className="package-grid">
              {packages.map((pkg) => (
                <PackageCard key={pkg.id} pkg={pkg} />
              ))}
            </div>
            <Pagination page={page} totalPages={totalPages} onPageChange={goToPage} />
          </>
        )}
      </div>

      <footer className="site-footer">
        <div className="container">
          <div className="footer-bottom">
            © {new Date().getFullYear()} Darazz Mystery Box। সর্বস্বত্ব সংরক্ষিত।
          </div>
        </div>
      </footer>
    </main>
  );
}

export default function CategoriesPage() {
  return (
    <Suspense fallback={<p style={{ textAlign: "center", padding: 60 }}>Loading...</p>}>
      <CategoriesContent />
    </Suspense>
  );
}