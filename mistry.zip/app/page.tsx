import { getCategories, getSettings } from "@/lib/api";
import PackageCard from "@/components/PackageCard";
import Link from "next/link";

export const dynamic = "force-dynamic";
export const revalidate = 0;

const FEATURES = [
  { icon: "💵", title: "ক্যাশ অন ডেলিভারি", desc: "সারা বাংলাদেশে হাতে পেয়ে টাকা পরিশোধের সুবিধা।" },
  { icon: "🛠️", title: "মানসম্পন্ন টুলস", desc: "যাচাই করা, টেকসই টুলস দিয়ে সাজানো প্রতিটি বক্স।" },
  { icon: "🚚", title: "দ্রুত ডেলিভারি", desc: "অর্ডার করার পর দ্রুততম সময়ে আপনার দরজায় পৌঁছে যাবে।" },
  { icon: "🔁", title: "সহজ রিটার্ন", desc: "কোনো সমস্যা হলে সহজ শর্তে রিটার্ন/এক্সচেঞ্জ সুবিধা।" },
];

const STEPS = [
  { title: "প্যাকেজ বেছে নিন", desc: "৩টা ক্যাটাগরি থেকে আপনার প্রয়োজন অনুযায়ী মিস্ত্রি বক্স বেছে নিন।" },
  { title: "তথ্য দিন", desc: "নাম, ঠিকানা ও মোবাইল নম্বর দিয়ে অর্ডার কনফার্ম করুন।" },
  { title: "হাতে পান, টাকা দিন", desc: "প্রোডাক্ট হাতে পেয়ে ক্যাশ অন ডেলিভারিতে মূল্য পরিশোধ করুন।" },
];

export default async function HomePage() {
  const { data: categories } = await getCategories();
  const { data: settings } = await getSettings();

  return (
    <main className="site-shell">
      <header className="site-header">
        <div className="container header-inner">
          <span className="brand-name"><span className="brand-icon">📦</span>Darazz Mystery Box</span>
          <nav className="nav-links">
            <Link href="/categories">ক্যাটাগরি</Link>
            <Link href="/contact">যোগাযোগ</Link>
          </nav>
        </div>
      </header>

      <section className="hero">
        <div className="container">
                    <h1>৫৯ টাকায় মিস্ত্রি বক্স</h1>
          <p>
            ছোট মেরামত থেকে শুরু করে বড় হোম-ইম্প্রুভমেন্ট — প্রয়োজন অনুযায়ী বাছাই করা মিস্ত্রি বক্স অর্ডার করুন,
            পৌঁছে যাবে আপনার দরজায়।
          </p>
        </div>
      </section>

      {/* Promo banner */}
      <div className="container">
        <div
          className="promo-banner"
          style={settings?.bannerImageUrl ? { backgroundImage: `url(${settings.bannerImageUrl})` } : undefined}
        >
          <div className="promo-banner-content">
            <span className="promo-banner-tag">{settings?.bannerTag || "🔥 সীমিত সময়ের অফার"}</span>
            <h2>{settings?.bannerTitle || "মিস্ত্রি বক্স — প্রতিটি বক্সে চমক!"}</h2>
            <p>{settings?.bannerSubtitle || "ক্যাশ অন ডেলিভারিতে অর্ডার করুন, ঘরে বসেই পেয়ে যান দরকারি সব টুলস।"}</p>
            <a href="#categories" className="btn btn-accent">
              এখনই অর্ডার করুন
            </a>
          </div>
        </div>
      </div>

      {/* Why choose us */}
      <section className="features-section">
        <div className="container">
          <h2 className="section-heading">কেন Darazz Mystery Box বেছে নেবেন</h2>
          <p className="section-subheading">
            হাজারো সন্তুষ্ট গ্রাহকের আস্থা অর্জন করেছি মানসম্পন্ন সেবা দিয়ে।
          </p>
          <div className="feature-grid">
            {FEATURES.map((f) => (
              <div key={f.title} className="feature-card">
                <div className="feature-icon">{f.icon}</div>
                <h3>{f.title}</h3>
                <p>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories + packages */}
      {(categories || []).map((category, index) => {
        const HOMEPAGE_LIMIT = 6;
        const visiblePackages = category.packages.slice(0, HOMEPAGE_LIMIT);
        const hasMore = category.packages.length > HOMEPAGE_LIMIT;

        return (
          <section key={category.id} id={index === 0 ? "categories" : undefined} className="category-section">
            <div className="container">
              <div className="category-heading">
                <h2>{category.name}</h2>
              </div>
              {category.description && <p className="category-desc">{category.description}</p>}

              {visiblePackages.length === 0 ? (
                <p className="package-desc">এই মুহূর্তে কোনো প্যাকেজ নেই।</p>
              ) : (
                <>
                  <div className="package-grid">
                    {visiblePackages.map((pkg) => (
                      <PackageCard key={pkg.id} pkg={pkg} />
                    ))}
                  </div>
                  {hasMore && (
                    <div style={{ textAlign: "center", marginTop: 24 }}>
                      <Link href={`/categories?category=${category.slug}`} className="btn btn-outline">
                        সব {category.name} দেখুন ({category.packages.length}টি)
                      </Link>
                    </div>
                  )}
                </>
              )}
            </div>
          </section>
        );
      })}

      {/* How it works */}
      <section className="steps-section">
        <div className="container">
          <h2 className="section-heading">কিভাবে অর্ডার করবেন</h2>
          <p className="section-subheading">মাত্র ৩টা সহজ ধাপে আপনার অর্ডার সম্পন্ন করুন।</p>
          <div className="steps-grid">
            {STEPS.map((step, i) => (
              <div key={step.title} className="step-card">
                <div className="step-number">{i + 1}</div>
                <h3>{step.title}</h3>
                <p>{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Policies */}
      <section className="policy-page-section">
        <div className="container">
          <h2 className="section-heading">নীতিমালা</h2>
          <p className="section-subheading">অর্ডার করার আগে অনুগ্রহ করে নিচের নীতিমালাগুলো পড়ে নিন।</p>

          <div className="policy-block">
            <h3 style={{ textAlign: "center", marginBottom: 16 }}>অর্ডার নীতিমালা</h3>

            <div className="policy-block-card">
              <h4>পেমেন্ট পদ্ধতি</h4>
              <p>সারা বাংলাদেশে ক্যাশ অন ডেলিভারি সুবিধা রয়েছে।</p>
            </div>

            <div className="policy-block-card">
              <h4>ন্যূনতম অর্ডার</h4>
              <p>অর্ডার করতে অবশ্যই উপলব্ধ প্যাকেজগুলোর (৬ / ৭ / ১০ প্যাক) যেকোনো একটি নির্বাচন করতে হবে।</p>
            </div>

            <div className="policy-block-card">
              <h4>ডেলিভারি চার্জ</h4>
              <p>মোট অর্ডারের সাথে নির্ধারিত ডেলিভারি চার্জ যোগ করা হবে।</p>
            </div>

            <div className="policy-block-card">
              <h4>ডেলিভারি প্রক্রিয়া</h4>
              <p>
                অর্ডারকৃত পণ্য সিল করা মিস্ত্রি বক্স হিসেবে ডেলিভারি করা হবে। বক্স খোলার আগে পণ্য চেক করার সুযোগ নেই,
                কারণ বক্সের ভিতরে কী থাকবে তা সম্পূর্ণ আপনার ভাগ্যের উপর নির্ভর করে।
              </p>
            </div>

            <div className="policy-block-card">
              <h4>অর্ডার নিশ্চিতকরণ</h4>
              <p>ডেলিভারির আগে আমাদের টিম আপনার অর্ডার নিশ্চিত করতে কল করতে পারে।</p>
            </div>

            <h3 style={{ textAlign: "center", margin: "32px 0 16px" }}>রিটার্ন নীতিমালা</h3>

            <div className="policy-block-card">
              <h4>রিটার্ন করার নিয়ম</h4>
              <p>
                • পার্সেল খোলার সময় অবশ্যই আনবক্সিং ভিডিও করতে হবে।
                <br />
                • ডেলিভারির ২৪ ঘণ্টার মধ্যে সমস্যার ক্ষেত্রে সাপোর্টে যোগাযোগ করতে হবে।
                <br />
                • অনুমোদনের পর রিটার্ন পিকআপ হতে ২-৩ দিন সময় লাগতে পারে।
                <br />
                • রিটার্নকৃত পার্সেল গ্রহণের পর রিফান্ড প্রসেস করা হবে।
              </p>
            </div>

            <div className="policy-note-box">
              <strong>নোট:</strong> মিস্ত্রি বক্স সম্পূর্ণ সিল করা অবস্থায় পাঠানো হয়। বক্সের ভিতরে কী থাকবে তা
              সম্পূর্ণ আপনার ভাগ্যের উপর নির্ভর করে।
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="site-footer">
        <div className="container">
          <div className="footer-inner">
            <div className="footer-brand">
              <span className="brand-name"><span className="brand-icon">📦</span>Darazz Mystery Box</span>
              <p>আপনার ঘর ও কাজের জন্য দরকারি টুলস, রেডি বক্সে — সরাসরি আপনার দরজায়।</p>
            </div>
            <div className="footer-contact">
              <strong>যোগাযোগ</strong>
              <a href="tel:+8801XXXXXXXXX">📞 01XXXXXXXXX</a>
              <a href="https://www.facebook.com/share/1EcqWzUf34/" target="_blank" rel="noreferrer">
                📘 Facebook Page
              </a>
            </div>
          </div>
          <div className="footer-bottom">© {new Date().getFullYear()} Darazz Mystery Box। সর্বস্বত্ব সংরক্ষিত।</div>
        </div>
      </footer>
    </main>
  );
}