import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Darazz Mystery Box | ড্যারাজ মিস্ট্রি বক্স",
  description: "আপনার ঘর ও কাজের জন্য দরকারি টুলস, রেডি বক্সে।",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="bn">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}